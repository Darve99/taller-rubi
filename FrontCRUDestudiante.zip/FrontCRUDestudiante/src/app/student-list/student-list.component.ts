import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Student } from '../student.model';
import { StudentService } from '../student.service';

@Component({
  selector: 'app-student-list',
  templateUrl: './student-list.component.html',
  styleUrls: ['./student-list.component.css']
})
export class StudentListComponent implements OnInit {
  students: Student[] = [];

  constructor(
    private studentService: StudentService,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.getStudents();
  }

  getStudents(): void {
    this.studentService.getStudents()
      .subscribe(
        (students: Student[]) => {
          this.students = students;
        },
        error => {
          console.error('Error al obtener estudiantes:', error);
          // Opcional: Puedes mostrar un mensaje de error al usuario aquí
        }
      );
  }

  editStudent(student: Student): void {
    // Redirigir al usuario a la página de edición de estudiante
    this.router.navigate(['/students/edit', student.id]);
  }

  deleteStudent(student: Student): void {
    this.studentService.deleteStudent(student.id ?? 0)
      .subscribe(
        () => {
          console.log('Estudiante eliminado:', student);
          // Actualizar la lista de estudiantes después de eliminar uno
          this.students = this.students.filter(s => s !== student);
          // Opcional: Puedes mostrar un mensaje de éxito al usuario aquí
        },
        error => {
          console.error('Error al eliminar estudiante:', error);
          // Opcional: Puedes mostrar un mensaje de error al usuario aquí
        }
      );
      window.location.reload();
  }

  navigateToAddStudent(): void {
    // Redirigir al usuario a la página de creación de estudiante
    this.router.navigate(['/students/new']);
  }
}
