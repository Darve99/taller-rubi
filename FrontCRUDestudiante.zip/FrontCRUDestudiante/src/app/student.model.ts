export interface Student {
    id?: number; // El ID es opcional, ya que podría no estar presente al crear un nuevo estudiante
    name: string;
    email: string;
    age: number;
  }
  