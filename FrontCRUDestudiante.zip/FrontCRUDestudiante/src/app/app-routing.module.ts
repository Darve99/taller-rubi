import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { StudentListComponent } from '../app/student-list/student-list.component';
import { StudentFormComponent } from '../app/student-form/student-form.component';

const routes: Routes = [
  { path: '', redirectTo: '/students', pathMatch: 'full' }, // Redireccionar al listado de estudiantes por defecto
  { path: 'students', component: StudentListComponent }, // Ruta para listar estudiantes
  { path: 'students/new', component: StudentFormComponent }, // Ruta para agregar un nuevo estudiante
  { path: 'students/edit/:id', component: StudentFormComponent }, // Ruta para editar un estudiante existente
  // Puedes agregar más rutas según sea necesario, por ejemplo, para ver detalles de un estudiante, eliminar un estudiante, etc.
  { path: '**', redirectTo: '/students' } // Redireccionar a la lista de estudiantes si la ruta no coincide con ninguna definida
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
