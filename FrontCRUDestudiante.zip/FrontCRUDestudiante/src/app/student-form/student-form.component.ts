import { Component, Input, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Student } from '../student.model';
import { StudentService } from '../student.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-student-form',
  templateUrl: './student-form.component.html',
  styleUrls: ['./student-form.component.css']
})
export class StudentFormComponent implements OnInit {
  @Input() student: Student | undefined;
  @Input() isNew?: boolean;

  constructor(
    private studentService: StudentService,
    private router: Router,
    private route: ActivatedRoute
  ) { }

  ngOnInit(): void {
    const studentId = this.route.snapshot.paramMap.get('id');
    if (studentId) {
      this.studentService.getStudentById(+studentId).subscribe(
        (student: Student) => {
          this.student = student;
          this.isNew = false;
        },
        error => {
          console.error('Error al obtener estudiante:', error);
        }
      );
    } else {
      this.isNew = true;
    }
  }

  onSubmit(form: NgForm): void {
    const studentData = form.value;
    if (this.student && this.student.id) {
      this.updateStudent(this.student.id, studentData);
    } else {
      this.createStudent(studentData);
    }
  }

  createStudent(studentData: Student): void {
    this.studentService.createStudent(studentData)
      .subscribe(
        (createdStudent: Student) => {
          console.log('Estudiante creado:', createdStudent);
          this.router.navigate(['/students']);
        },
        error => {
          console.error('Error al crear estudiante:', error);
        }
      );
  }

  updateStudent(studentId: number, studentData: Student): void {
    this.studentService.updateStudent(studentId, studentData)
      .subscribe(
        (updatedStudent: Student) => {
          console.log('Estudiante actualizado:', updatedStudent);
          
        },
        error => {
          console.error('Error al actualizar estudiante:', error);
        }
      );
  }
  goToStudentList(): void {
    this.router.navigate(['/students']);
  }
}
