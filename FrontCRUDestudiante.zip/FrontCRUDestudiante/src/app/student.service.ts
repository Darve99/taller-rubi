import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, Subject } from 'rxjs';
import { tap } from 'rxjs/operators';
import { Student } from './student.model';
import { WebhookService } from './webhook.service'; // Importa el servicio de webhooks

@Injectable({
  providedIn: 'root'
})
export class StudentService {
  private apiUrl = 'http://localhost:3000/students'; // Actualiza esta URL con la URL de tu backend
  public students: Subject<Student[]> = new Subject<Student[]>();

  constructor(private http: HttpClient, private webhookService: WebhookService) { }

  getStudents(): Observable<Student[]> {
    return this.http.get<Student[]>(this.apiUrl)
      .pipe(
        tap(students => this.students.next(students))
      );
  }
  getStudentById(id: number): Observable<Student> {
    return this.http.get<Student>(`${this.apiUrl}/${id}`)
    .pipe(
      tap(student => this.webhookService.handleEvent('student_viewed', student))
    )
  }

  createStudent(student: Student): Observable<Student> {
    return this.http.post<Student>(this.apiUrl, student)
      .pipe(
        tap(createdStudent => this.webhookService.handleEvent('student_created', createdStudent))
      );
  }

  updateStudent(id: number, student: Student): Observable<Student> {
    const url = `${this.apiUrl}/${id}`;
    return this.http.put<Student>(url, student)
      .pipe(
        tap(updatedStudent => this.webhookService.handleEvent('student_updated', updatedStudent))
      );
  }

  deleteStudent(id: number): Observable<void> {
    const url = `${this.apiUrl}/${id}`;
    return this.http.delete<void>(url)
      .pipe(
        tap(() => this.webhookService.handleEvent('student_deleted', { id }))
      );
  }
}
